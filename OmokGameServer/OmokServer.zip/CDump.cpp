#include <Windows.h>

#include "CDump.h"

long CDump::_dumpCount = 0;