#pragma once

enum class en_JOB_TYPE : DWORD
{
	en_JOB_ON_ACCEPT = 0,
	en_JOB_ON_RECV = 1,
	en_JOB_ON_RELEASE = 2,
	en_JOB_SERVER_DOWN = 3,
	en_JOB_SYSTEM = 4,
	en_JOB_CHECK = 5,
};

struct SJob
{
	en_JOB_TYPE type;
	unsigned __int64 sessionId;
	CPacket* data;
};
